from __future__ import unicode_literals
from django.db import models
from django.contrib import messages
import re, bcrypt
import datetime


class Tripmessage(models.Manager):
	def messages(self, postdata):
		err_messages = []
		if  len(postdata['destination'])< 1:
			mess = 'destination must not be blank'
			err_messages.append(mess)
		if  len(postdata['description'])< 1:
			mess = 'description must not be blank'
			err_messages.append(mess)
		# if  postdata['travel_date_from'] <= datetime.datetime.now():
		# 	mess = 'travel_date_from must be later than today'
		# 	err_messages.append(mess)
		if  len(postdata['travel_date_from'])< 1:
			mess = 'travel_date_from must not be blank'
			err_messages.append(mess)
		if  len(postdata['travel_date_to'])< 1:
			mess = 'travel_date_to must not be blank'
			err_messages.append(mess)
		# if  postdata['travel_date_from'] > postdata['travel_date_from']:
		# 	mess = 'travel_date_to must be later than from'
		# 	err_messages.append(mess)
		if err_messages:
			return {'err_messages': err_messages}
		else:
			Trip.objects.create(destination = postdata['destination'], description = postdata['description'], travel_date_from = postdata['travel_date_from'], travel_date_to = postdata['travel_date_to'])
			success_messages = 'Successfully added a trip'
			return {'success_messages' : success_messages}



class Usermessage(models.Manager):
	def messages(self, postdata):
		err_messages = []
		if  len(postdata['name'])< 3:
			mess = 'name must be at least two characters length'
			err_messages.append(mess)
		if  len(postdata['username']) < 3:
			mess = 'username is too short or left blank'
			err_messages.append(mess)
		if re.compile(r'^[a-zA-Z]+$').match(postdata['name']) == None:
			mess = 'name can only contain letters'
			err_messages.append(mess)
		if  len(postdata['password']) < 5:
			mess = 'password must be greater than 4 characters in length'
			err_messages.append(mess)
		if re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{4,}').match(postdata['password']) == None:
			mess = 'password must be a minimum 4 characters at least 1 upper and 1 lowercase, 1 number and 1 special character'
			err_messages.append(mess)
		if postdata['password_confirmation'] != postdata['password']:
			mess = 'password confirmation must match password'
			err_messages.append(mess)
		if err_messages:
			return {'err_messages': err_messages}
		else:
			hashed_pass = bcrypt.hashpw(postdata['password'].encode('utf-8'), bcrypt.gensalt())
			User.objects.create(name = postdata['name'], username = postdata['username'], password = hashed_pass)
			success_messages = 'Successfully registered as: ' + postdata['username']
			return {'success_messages' : success_messages}
	def login_messages(self, postdata):
		hashed_pass = bcrypt.hashpw(postdata['password'].encode('utf-8'), bcrypt.gensalt())
		err_messages = []
		usrname = User.objects.filter(username=postdata['username'])
		if not User.objects.filter(username=postdata['username']).exists():
			err_messages.append('username not found')
		# if not hashed_pass in usrname:
		# 	err_messages.append('password not found in any user instances')
		# 	print '************************43'
		# 	print hashed_pass
		# 	print usrname
		if err_messages:
			return {'err_messages': err_messages}
		else:
			success_messages = 'logged in as ' + postdata['username']
			return {'success_messages': success_messages}

class User(models.Model):
	name = models.CharField(max_length=100)
	username = models.CharField(max_length=100)
	password = models.CharField(max_length=100)
	added = models.DateTimeField(auto_now_add=True)
	edited = models.DateTimeField(auto_now=True)
	objects = Usermessage()

class Trip(models.Model):
	destination = models.CharField(max_length=100)
	travel_start_date = models.DateTimeField(auto_now=False)
	travel_end_date = models.DateTimeField(auto_now=False)
	plan = models.CharField(max_length=100)
	added = models.DateTimeField(auto_now_add=True)
	edited = models.DateTimeField(auto_now=True)
	users = models.ManyToManyField(User, related_name='trips')
	objects = Tripmessage()



# Create your models here.
