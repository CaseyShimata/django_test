from __future__ import unicode_literals

from django.apps import AppConfig


class DjangoTestAppConfig(AppConfig):
    name = 'django_test_app'
