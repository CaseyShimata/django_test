from django.shortcuts import render, redirect, HttpResponse
from .models import User, Trip, Usermessage
from django.contrib import messages



def homepage(request):
	return render (request, 'django_test_app/homepage.html')

def register(request):
	check_manager = User.objects.messages(request.POST)
	if 'err_messages' in check_manager:
		for message in check_manager['err_messages']:
			messages.error(request, message)
		return redirect('/')
	if 'success_messages' in check_manager:
		messages.success(request, check_manager['success_messages'])
		return redirect('/')

def login(request):
	check_manager = User.objects.login_messages(request.POST)
	if 'err_messages' in check_manager:
		for message in check_manager['err_messages']:
			messages.error(request, message)
		return redirect('/')
	if 'success_messages' in check_manager:
		request.session['username'] = request.POST['username']
		messages.success(request, check_manager['success_messages'])
		return redirect('/success_page')

def success_page(request):
	if 'username' not in request.session:
		return redirect('/')
	trip_dictionary = {'Trip' : Trip.objects.all()}
	return render (request, 'django_test_app/success_page.html', trip_dictionary)


def trip_info_page(request, url_id):
	this_trip = Trip.objects.get(id=url_id)
	# this_user = User.objects.get(id=) #foreign key
	return render (request, 'django_test_app/trip_info_page.html')


def join(request, url_id):
	this_trip = Trip.objects.get(id=url_id)
	this_user = User.objects.get(username= request.session['username']).id

	return redirect('/')


def add_page(request):

	return render (request, 'django_test_app/add_page.html')


def add(request):
	check_manager = Trip.objects.messages(request.POST)
	if 'err_messages' in check_manager:
		for message in check_manager['err_messages']:
			messages.error(request, message)
		return redirect('/add_page')
	if 'success_messages' in check_manager:
		messages.success(request, check_manager['success_messages'])
		return redirect('/success_page')


def log_out(request):
	request.session.pop('username')
	request.session.modified = True
	return redirect('/')

# Create your views here.
